1. drag the whole folder to your desktop
2. open the stuff folder then open the shortcut
3.click on f1
4 begin the security by entering the password then the second peice which is secret after